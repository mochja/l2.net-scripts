= Anti-Antibot Kamael.cz By mochitto
= Last update: 13. 3. 2011 @14:00
============================================
SERVER IP: 81.0.254.162
Start at char select window

# CHANGELOG
v5
 * updated to rc2

v4
 * updated to RC1 protection

v3
 * mass code change
 * crypted version

v2
 * code update

v1
 * first relase
