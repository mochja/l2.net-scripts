= Anti-Antibot Kamael.cz By mochitto
= Last update: 12. 3. 2011 @13:20
============================================
SERVER IP: 81.0.254.162
Start at char select window

# CHANGELOG
v4
 * updated to RC1 protection

v3
 * mass code change
 * crypted version

v2
 * code update

v1
 * first relase
