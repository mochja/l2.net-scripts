= Anti-Antibot Kamael.cz By mochitto
= Last update: 11. 3. 2011 @15:20
============================================
SERVER IP: 81.0.254.162


# CHANGELOG
v3
 * mass code change
 * crypted version

v2
 * code update

v1
 * first relase
